function AddLink() {
    return (
        <div className="add-link">
            Add Link Sayfası
        </div>
    )
}

export default AddLink;