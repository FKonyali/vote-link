import "./App.sass";
import React, { useEffect, useState } from "react";
import Header from "./components/Header";
import LinkItem from "./components/LinkItem";
import AddLink from "./views/AddLink";

import DummyData from "./func/DummyData";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

export default function App() {
  return (
    <Router>
      <div className="container">
        <Header />
        <div>
          <nav>
            <ul>
              <li>
                <Link to="/">Home</Link>
              </li>
              <li>
                <Link to="/add-link">Add Link</Link>
              </li>
            </ul>
          </nav>
          <div className="order">
            Order by
            <div className="order__content">
              <div className="order__item">Most Voted (Z - A)</div>
              <div className="order__item">Less Voted (A - Z)</div>
            </div>
          </div>
          <Switch>
            <Route path="/add-link">
              <AddLink />
            </Route>
            <Route path="/">
              <Home />
            </Route>
          </Switch>
        </div>
      </div>
    </Router>
  );
}

const Links = () => {
  const [lastData, setLastData] = useState();

  useEffect(() => {
    getAllData();
  }, [DummyData]);

  function getAllData() {
    let getData =
      (localStorage.getItem("links")
        ? JSON.parse(localStorage.getItem("links"))
        : DummyData) || DummyData;

      setLastData(getData.links.sort((a, b) => b.point - a.point));
      // localStorage.setItem("links", JSON.stringify(lastData));
  }

  function boost(id, count) {
    let getIndex = lastData.findIndex((x) => x.id === id);
    console.log(lastData[getIndex]);
    if(lastData[getIndex] !== undefined) {
      // let changed = lastData[getIndex];
      debugger;
      let newArr = lastData;
      let changed = newArr.splice(getIndex,1);
      changed[0].point = count;
      // newArr = [...newArr, changed[0]];
      debugger;
      setLastData(newArr => [...newArr, changed[0]]);
    }

      // localStorage.setItem("links", JSON.stringify(lastData));
    
    
  }

  useEffect(() => {

  }, [lastData]);


  const sort = (data) => {
    return data.sort((a, b) => b.point - a.point);
  }

  return lastData ? (
    lastData.map((item) => {
      return (
        <LinkItem
          onCountChange={(id, count) => boost(id, count)}
          item={item}
          key={item.id}
        />
      );
    })
  ) : (
    <div>
      No found links
    </div>
  );
};

function Home() {
  return (
    <div className="link-container">
      <Links />
    </div>
  );
}
