import { Link } from "react-router-dom";
import './Header.sass'

export default function Header() {
    return(
        <div className="header">
            <Link to="/" className="header__logo">
                Hepsiburada.com
            </Link>
            <div className="header__right">
                <strong>Link</strong>
                <span>VOTE</span>
                <span>Challenge</span>
            </div>
        </div>
    )
}