import './LinkItem.sass'
import React, { useState, useEffect } from 'react'

export default function LinkItem({onCountChange, ...props}) {
    // console.log(onCountChange);

    const {id, link, point, title} = props.item;
    const [count, setCount] = useState(point);

    useEffect(() => {
        onCountChange && onCountChange()
    }, [count]);

    // let getLinks = localStorage.getItem('links') ? JSON.parse(localStorage.getItem('links')) : [];


    
    return (
        <div className="link-item">
            <div className="link-item__point">
                <div className="link-item__number">
                    { count }
                </div>
                POINTS
            </div>
            <div className="link-item__right">
                <div className="link-item__right-top">
                    <h2 className="link-item__right-title">
                        { title }
                    </h2>
                    <a href={link} target="_blank" rel="noreferrer" className="link-item__right-link">
                        ({ link })
                    </a>
                </div>
                <div className="link-item__right-bot">
                    <button className="link-item__btn" onClick={() => onCountChange(id, count + 1)}>
                        <i className="icon-arrow-up"></i> Up Vote
                    </button>
                    <button className="link-item__btn" onClick={() => onCountChange(id, count - 1)}>
                        <i className="icon-arrow-down"></i> Down Vote
                    </button>
                </div>
            </div>
        </div>
    )
}