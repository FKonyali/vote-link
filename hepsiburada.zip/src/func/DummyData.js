let data = {
    "links": [
        {
            "id": 0,
            "title": "Hacker News",
            "point": 6,
            "link": "https://news.ycombinator.com/"
        },
        {
            "id": 1,
            "title": "Hepsiburada",
            "point": 10,
            "link": "https://hepsiburada.com/"
        },
        {
            "id": 2,
            "title": "Product Hunt",
            "point": 4,
            "link": "https://www.producthunt.com/"
        },
        {
            "id": 3,
            "title": "REDDIT",
            "point": 10,
            "link": "https://www.reddit.com/"
        },
        {
            "id": 4,
            "title": "9gag",
            "point": 7,
            "link": "https://9gag.com/"
        },
        {
            "id": 5,
            "title": "Facebook",
            "point": 2,
            "link": "https://facebook.com/"
        },
        {
            "id": 6,
            "title": "Twitter",
            "point": 15,
            "link": "https://twitter.com/"
        },
        {
            "id": 7,
            "title": "Wikipedia",
            "point": 16,
            "link": "https://www.wikipedia.org/"
        }
    ]
}

export default data